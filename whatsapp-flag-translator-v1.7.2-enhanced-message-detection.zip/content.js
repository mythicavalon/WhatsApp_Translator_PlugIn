/**
 * WhatsApp Flag Translator - Firefox Content Script
 * BULLETPROOF VERSION - Guaranteed to show visual confirmation
 */

// =============================================================================
// IMMEDIATE EXECUTION - This runs as soon as the script is injected
// =============================================================================

// IMMEDIATE LOGGING - This should appear first
console.log("✅ WhatsApp Flag Translator - Extension Loaded");

// Add to window for debugging
window.WHATSAPP_TRANSLATOR_LOADED = true;
console.log("🔧 Set window.WHATSAPP_TRANSLATOR_LOADED = true");

// =============================================================================
// VISUAL CONFIRMATION BANNER - Shows immediately
// =============================================================================

function createVisualBanner() {
  console.log("🎨 Creating visual confirmation banner...");
  
  const banner = document.createElement('div');
  banner.id = 'whatsapp-translator-banner';
  
  const bannerContent = document.createElement('div');
  bannerContent.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background: #ff4444;
    color: white;
    padding: 10px;
    text-align: center;
    font-weight: bold;
    font-size: 16px;
    z-index: 999999;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-family: Arial, sans-serif;
  `;
  
  const text = document.createTextNode('🌍 WhatsApp Flag Translator Extension Loaded Successfully!');
  bannerContent.appendChild(text);
  
  const closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.cssText = `
    margin-left: 20px;
    background: white;
    color: #ff4444;
    border: none;
    padding: 5px 10px;
    border-radius: 3px;
    cursor: pointer;
    font-weight: bold;
  `;
  
  // Add event listener instead of inline onclick
  closeButton.addEventListener('click', () => {
    banner.remove();
  });
  
  bannerContent.appendChild(closeButton);
  banner.appendChild(bannerContent);
  
  // Insert banner immediately
  if (document.body) {
    document.body.appendChild(banner);
    console.log("✅ Visual banner added to body");
  } else {
    // If body doesn't exist yet, add to document element
    document.documentElement.appendChild(banner);
    console.log("✅ Visual banner added to document element");
  }
  
  // Auto-remove after 10 seconds
  setTimeout(() => {
    const bannerElement = document.getElementById('whatsapp-translator-banner');
    if (bannerElement) {
      bannerElement.remove();
      console.log("🗑️ Visual banner auto-removed");
    }
  }, 10000);
}

// =============================================================================
// IMMEDIATE BANNER CREATION
// =============================================================================

// Try to create banner immediately
try {
  createVisualBanner();
} catch (error) {
  console.error("❌ Error creating banner:", error);
}

// Fallback - try again when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log("📄 DOMContentLoaded - trying banner again");
    createVisualBanner();
  });
}

// Another fallback - try when window loads
window.addEventListener('load', () => {
  console.log("🪟 Window loaded - trying banner again");
  createVisualBanner();
});

// =============================================================================
// WHATSAPP DETECTION AND CORE LOADING
// =============================================================================

console.log("🔍 Checking if this is WhatsApp Web...");
const isWhatsAppWeb = document.location.href.includes('web.whatsapp.com');
console.log("📱 Is WhatsApp Web:", isWhatsAppWeb);

if (isWhatsAppWeb) {
  console.log("✅ On WhatsApp Web - proceeding with translator initialization");
  
  // Translator core is now loaded directly via manifest
  
  // Initialize the translator
  function initializeTranslator() {
    console.log("🚀 Initializing WhatsApp Translator...");
    
    try {
      // Check if core is available
      if (typeof WhatsAppTranslatorCore !== 'undefined') {
        console.log("✅ WhatsAppTranslatorCore found");
        
        // Firefox uses 'browser' API
        const browserAPI = typeof browser !== 'undefined' ? browser : chrome;
        
        class WhatsAppTranslator extends WhatsAppTranslatorCore {
          constructor() {
            console.log("🔧 Creating WhatsAppTranslator instance");
            super(browserAPI);
            this.init();
          }
        }
        
        // Create global instance
        window.whatsappTranslator = new WhatsAppTranslator();
        console.log("🎉 WhatsApp Translator initialized successfully!");
        
        // Update banner to show success
        const banner = document.getElementById('whatsapp-translator-banner');
        if (banner) {
          // Clear existing content
          banner.innerHTML = '';
          
          const successContent = document.createElement('div');
          successContent.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #25d366;
            color: white;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            z-index: 999999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            font-family: Arial, sans-serif;
          `;
          
          const successText = document.createTextNode('🎉 WhatsApp Flag Translator Ready! React with flag emojis to translate messages.');
          successContent.appendChild(successText);
          
          const successCloseButton = document.createElement('button');
          successCloseButton.textContent = 'Close';
          successCloseButton.style.cssText = `
            margin-left: 20px;
            background: white;
            color: #25d366;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            font-weight: bold;
          `;
          
          // Add event listener instead of inline onclick
          successCloseButton.addEventListener('click', () => {
            banner.remove();
          });
          
          successContent.appendChild(successCloseButton);
          banner.appendChild(successContent);
        }
        
      } else {
        console.warn("⚠️ WhatsAppTranslatorCore not found - using fallback");
        // Create a simple fallback
        window.whatsappTranslator = {
          ready: false,
          error: "Core not loaded"
        };
      }
    } catch (error) {
      console.error("❌ Error initializing translator:", error);
    }
  }
  
  // Start initialization process
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeTranslator);
  } else {
    initializeTranslator();
  }
  
} else {
  console.log("⚠️ Not on WhatsApp Web - extension will not initialize");
}

// =============================================================================
// TESTING FUNCTIONS
// =============================================================================

// Global test function
window.testWhatsAppTranslator = function() {
  console.log("🧪 === WhatsApp Translator Test ===");
  console.log("- Extension loaded:", true);
  console.log("- Current URL:", document.location.href);
  console.log("- Is WhatsApp Web:", document.location.href.includes('web.whatsapp.com'));
  console.log("- Document title:", document.title);
  console.log("- Translator instance:", !!window.whatsappTranslator);
  console.log("- DOM elements with data-testid:", document.querySelectorAll('[data-testid]').length);
  
  if (window.whatsappTranslator) {
    console.log("- Translator ready:", window.whatsappTranslator.ready !== false);
    if (window.whatsappTranslator.flagToLanguage) {
      console.log("- Supported languages:", Object.keys(window.whatsappTranslator.flagToLanguage).length);
    }
  }
  
  return {
    loaded: true,
    url: document.location.href,
    isWhatsApp: document.location.href.includes('web.whatsapp.com'),
    translator: !!window.whatsappTranslator,
    elements: document.querySelectorAll('[data-testid]').length
  };
};

// Global test functions for debugging
window.testWhatsAppTranslator = () => {
  console.log('🧪 Testing WhatsApp Translator...');
  if (window.whatsappTranslator) {
    console.log('✅ Translator instance exists');
    console.log('⚙️ Settings:', window.whatsappTranslator.settings);
    console.log('🏃‍♂️ Running reaction check...');
    window.whatsappTranslator.checkForReactions(document.body);
  } else {
    console.log('❌ Translator instance not found');
  }
};

window.debugReactions = () => {
  console.log('🔍 Debug: Looking for reaction elements...');
  const reactionSelectors = [
    '[data-testid*="reaction"]',
    '.message-reaction',
    '[title*="reacted"]',
    '[aria-label*="reacted"]',
    '[aria-label*="reaction"]',
    '[data-testid="reactions"]',
    '.reactions-container',
    '[data-testid="emoji-reactions"]',
    'button[aria-label*="reaction"]',
    'span[aria-label*="reaction"]',
    'div[aria-label*="reaction"]'
  ];
  
  reactionSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`Found ${elements.length} elements with selector: ${selector}`);
      elements.forEach((el, index) => {
        console.log(`  ${index + 1}:`, el.tagName, el.getAttribute('aria-label')?.substring(0, 50));
        // Debug each reaction element
        if (window.whatsappTranslator) {
          window.whatsappTranslator.debugReactionElement(el);
        }
      });
    }
  });
};

window.forceReactionCheck = () => {
  console.log('🚀 Force checking all messages for reactions...');
  if (window.whatsappTranslator) {
    const messages = document.querySelectorAll('[data-testid="msg-container"]');
    console.log(`Found ${messages.length} message containers`);
    messages.forEach((msg, index) => {
      console.log(`Checking message ${index + 1}...`);
      window.whatsappTranslator.checkForReactions(msg);
    });
  }
};

window.findAllFlags = () => {
  console.log('🚩 Finding all flag emojis on the page...');
  if (window.whatsappTranslator) {
    return window.whatsappTranslator.findAllFlags();
  } else {
    console.log('❌ Translator instance not found');
    return [];
  }
};

window.debugReactionElement = (element) => {
  console.log('🔍 Debugging specific reaction element...');
  if (window.whatsappTranslator && element) {
    return window.whatsappTranslator.debugReactionElement(element);
  } else {
    console.log('❌ Translator instance not found or element not provided');
  }
};

// =============================================================================
// FINAL CONFIRMATION
// =============================================================================

  console.log("🎯 Firefox content script setup complete!");
  console.log("💡 To test: Open browser console and run testWhatsAppTranslator()");
  console.log("🔍 Look for the red banner at the top of the page as visual confirmation");
  
  // Add global test functions
  window.testWhatsAppTranslator = function() {
    console.log("🧪 Testing WhatsApp Translator...");
    
    if (window.whatsappTranslator) {
      console.log("✅ Translator instance found:", window.whatsappTranslator);
      
      // Test flag emoji extraction
      const testText = "🇯🇵🇩🇪🇫🇷";
      const flags = testText.match(/[\u{1F1E6}-\u{1F1FF}]{2}/gu) || [];
      console.log("🏳️ Flag test - Input:", testText, "Flags found:", flags);
      
      // Test reaction detection on current page
      console.log("🔍 Scanning page for reactions...");
      const reactions = document.querySelectorAll('[data-testid*="reaction"], .message-reaction, [title*="reacted"]');
      console.log("🎭 Found reactions on page:", reactions.length);
      reactions.forEach((reaction, i) => {
        console.log(`  Reaction ${i+1}:`, reaction, "Text:", reaction.textContent);
      });
      
      // Test message containers
      const messages = document.querySelectorAll('[data-testid="msg-container"]');
      console.log("💬 Found message containers:", messages.length);
      
    } else {
      console.log("❌ Translator instance not found");
    }
  };
  
  window.manualReactionTest = function() {
    console.log("🔧 Manual reaction test...");
    if (window.whatsappTranslator && window.whatsappTranslator.checkForReactions) {
      // Test on entire document
      window.whatsappTranslator.checkForReactions(document.body);
    }
  };

  // New debug function to analyze current DOM for reactions
  window.debugReactions = function() {
    console.log('🔍 DEBUG: Analyzing current page for reactions...');
    
    // Search for all potential reaction elements
    const selectors = [
      'button[aria-label*="reaction"]',
      'span[aria-label*="reaction"]', 
      'div[aria-label*="reaction"]',
      '[data-testid*="reaction"]',
      'button[aria-label*="🇯🇵"]',
      'button[aria-label*="🇩🇪"]', 
      'button[aria-label*="🇪🇸"]',
      'button[aria-label*="🇫🇷"]',
      'span[aria-label*="🇯🇵"]',
      'span[aria-label*="🇩🇪"]'
    ];
    
    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        console.log(`🎯 Found ${elements.length} elements with selector: ${selector}`);
        elements.forEach((el, i) => {
          console.log(`  Element ${i+1}:`, el);
          console.log(`  Aria-label: "${el.getAttribute('aria-label')}"`);
          console.log(`  Classes: "${el.className}"`);
          console.log(`  Text: "${el.textContent}"`);
        });
      }
    });
    
    // Also check for any elements containing flag emojis
    const allElements = document.querySelectorAll('*');
    const flagElements = [];
    const flagRegex = /[\u{1F1E6}-\u{1F1FF}]{2}/u;
    
    allElements.forEach(el => {
      const ariaLabel = el.getAttribute('aria-label') || '';
      const title = el.getAttribute('title') || '';
      const text = el.textContent || '';
      
      if (flagRegex.test(ariaLabel) || flagRegex.test(title) || flagRegex.test(text)) {
        flagElements.push({
          element: el,
          ariaLabel,
          title,
          text: text.substring(0, 50),
          tagName: el.tagName,
          className: el.className
        });
      }
    });
    
    console.log(`🚩 Found ${flagElements.length} elements with flag emojis:`, flagElements);
    
    return {
      totalReactionElements: selectors.reduce((count, sel) => count + document.querySelectorAll(sel).length, 0),
      flagElements: flagElements.length
    };
  };

  // Force reaction check function
  window.forceReactionCheck = function() {
    console.log('🔧 Force checking entire page for reactions...');
    if (window.whatsappTranslator && window.whatsappTranslator.checkForReactions) {
      // Check the entire document
      window.whatsappTranslator.checkForReactions(document.body);
      console.log('✅ Force reaction check completed');
    } else {
      console.log('❌ Translator not found');
    }
  };

  // Find all elements containing flag emojis on the page
  window.findAllFlags = function() {
    console.log('🚩 Scanning entire page for flag emojis...');
    const flagRegex = /[\u{1F1E6}-\u{1F1FF}]{2}/u;
    const allElements = document.querySelectorAll('*');
    const flagElements = [];
    
    allElements.forEach(el => {
      const ariaLabel = el.getAttribute('aria-label') || '';
      const title = el.getAttribute('title') || '';
      const text = el.textContent || '';
      
      if (flagRegex.test(ariaLabel) || flagRegex.test(title) || flagRegex.test(text)) {
        flagElements.push({
          element: el,
          tagName: el.tagName,
          className: el.className,
          ariaLabel,
          title,
          text: text.substring(0, 30),
          innerHTML: el.innerHTML.substring(0, 100)
        });
      }
    });
    
    console.log(`🚩 Found ${flagElements.length} elements with flag emojis:`, flagElements);
    return flagElements;
  };

// Minimal heartbeat - only log twice to confirm it's working
let logCount = 0;
const intervalId = setInterval(() => {
  logCount++;
  if (logCount <= 2) {
    console.log(`⏰ Extension heartbeat ${logCount} - Script is running`);
  }
  
  if (logCount >= 2) { // Stop after 10 seconds
    clearInterval(intervalId);
  }
}, 5000);